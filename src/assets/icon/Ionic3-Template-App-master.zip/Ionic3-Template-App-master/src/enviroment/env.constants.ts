export const Config = {
  firebase: {
    apiKey: "AIzaSyA8Bk08xHF6Ra-Eiv8FrO9xaY17x07vbFk",
    authDomain: "angular4-workshop.firebaseapp.com",
    databaseURL: "https://angular4-workshop.firebaseio.com",
    projectId: "angular4-workshop",
    storageBucket: "angular4-workshop.appspot.com",
    messagingSenderId: "127243035046"
  },
  google_web_client_id: "904616137099-730tr4g3m6mhfldojejlren97nk3ckod.apps.googleusercontent.com",
  firebase_tables: {
    User: 'users',
    Tasks: 'tasks'
  }
};