export class FirebaseModel {
    updatedAt?: number;
    createdAt?: number;
}